#!/bin/bash

process_files() {
     directory="$1"
     seed="$2"

    for file_in in "$directory"/*; do
        if [[ -f "$file_in" && ! $file_in == *.encrypted ]]; then
            if [[ -s "$file_in" ]]; then
               file_out="$file_in.encrypted"
                ./encryption "$file_in" "$file_out" "$seed"
            else 
                ./encryption "$file_in" 
            fi
        elif [[ -d "$file_in" ]]; then
            process_files "$file_in" "$seed" 
        fi
    done
}



directory="$1"
seed="$2"

process_files "$directory" "$seed"

