#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void generate_key(unsigned int seed, char key[], int length){
	srand(seed);
	for(int i = 0; i < length; i++){
		key[i] = rand() % 256;
	}
}

int main(int argc, char *argv[]){
	if(argv[2] == NULL || argv[3] == NULL){
		printf("Encryption of %s failed\n", argv[1]); 
		return -1;
	}
	FILE *in = fopen(argv[1], "r");
	FILE *out = fopen(argv[2], "w");
	unsigned int seed = atoi(argv[3]);
	int ch = fgetc(in);
	int in_size = 0;
	
	while(ch != EOF){
		in_size++;
		ch = fgetc(in);
	}

	rewind(in);
	char key[in_size];
	
	generate_key(seed, key, in_size);
	
	char byte;
	
	for(int i = 0; i < in_size; i++){
		byte = fgetc(in)^key[i];
		fputc(byte, out);
	}
	
	fclose(in);
	fclose(out);
	
	printf("Encryption of %s succeeded\n", argv[1]);
	
	return 0;
}
